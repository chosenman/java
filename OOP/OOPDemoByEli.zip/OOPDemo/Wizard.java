class Wizard {
    Wizard(){

    }

}