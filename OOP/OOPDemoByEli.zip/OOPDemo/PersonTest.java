class PersonTest {
    public static void main(String[] args){

        Person dude1 = new Person();
        Person dude2 = new Person(100);
        Person dude3 = new Person(10, "Bob");

        // dude3.sayHello();

        Ninja black = new Ninja();
        black.sayHello();
    }

}