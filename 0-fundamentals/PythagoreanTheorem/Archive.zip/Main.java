public class Main{
  public static void main(String[] args){
    ImportPythagorean pythagorean = new ImportPythagorean();
    double c = pythagorean.calculateHypoteneuse(2, 2);
    System.out.println(c);
    // int four = 4;
    // double squareRoot = Math.sqrt(four);
    // System.out.println(squareRoot);
  }
}
