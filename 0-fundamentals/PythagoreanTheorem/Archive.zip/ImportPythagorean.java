public class ImportPythagorean {
  public double calculateHypoteneuse(int legA, int legB){

    return Math.sqrt( legA*legA + legB*legB);
  }
}
